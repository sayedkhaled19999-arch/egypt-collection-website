import { Metadata } from 'next';
import JobCard from '@/components/JobCard';

export const metadata: Metadata = {
  title: 'الوظائف المتاحة - شركتنا',
  description: 'استعرض الفرص الوظيفية المتاحة وانضم لفريقنا المتميز',
};

const jobs = [
  {
    id: 'مطور-واجهات-أمامية',
    title: 'مطور واجهات أمامية',
    description:
      'نبحث عن مطور واجهات أمامية محترف لديه خبرة في React وNext.js. ستعمل على تطوير واجهات مستخدم حديثة وتفاعلية لمشاريع عملائنا.',
    location: 'الرياض',
    type: 'دوام كامل',
  },
  {
    id: 'مطور-خلفية',
    title: 'مطور خلفية',
    description:
      'نحتاج إلى مطور خلفية متمكن لديه خبرة في Node.js وقواعد البيانات. ستكون مسؤولاً عن بناء وصيانة APIs وأنظمة خلفية قوية.',
    location: 'جدة',
    type: 'دوام كامل',
  },
  {
    id: 'مصمم-واجهات',
    title: 'مصمم واجهات المستخدم',
    description:
      'مصمم UI/UX مبدع مطلوب للانضمام لفريقنا. يجب أن تكون لديك خبرة في Figma وفهم عميق لتجربة المستخدم.',
    location: 'الرياض',
    type: 'دوام كامل',
  },
  {
    id: 'مدير-مشاريع',
    title: 'مدير مشاريع تقنية',
    description:
      'نبحث عن مدير مشاريع ذو خبرة في إدارة المشاريع التقنية والتنسيق بين الفرق المختلفة. معرفة بمنهجيات Agile مطلوبة.',
    location: 'عن بُعد',
    type: 'دوام كامل',
  },
  {
    id: 'محلل-بيانات',
    title: 'محلل بيانات',
    description:
      'محلل بيانات مطلوب للعمل على تحليل البيانات واستخراج رؤى قيّمة. خبرة في SQL وPython ضرورية.',
    location: 'الدمام',
    type: 'دوام جزئي',
  },
  {
    id: 'مهندس-DevOps',
    title: 'مهندس DevOps',
    description:
      'نحتاج إلى مهندس DevOps لإدارة البنية التحتية والتكامل المستمر. خبرة في Docker وKubernetes وAWS مطلوبة.',
    location: 'الرياض',
    type: 'دوام كامل',
  },
];

export default function JobsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Section */}
      <section className="bg-gradient-to-l from-blue-700 to-blue-900 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">الوظائف المتاحة</h1>
          <p className="text-xl text-gray-100">
            اكتشف الفرصة المثالية لك وانضم إلى فريقنا المتميز
          </p>
        </div>
      </section>

      {/* Jobs Grid */}
      <section className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <p className="text-gray-600 text-lg">
            لدينا <span className="font-bold text-blue-600">{jobs.length}</span> وظيفة متاحة حالياً
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {jobs.map((job) => (
            <JobCard
              key={job.id}
              id={job.id}
              title={job.title}
              description={job.description}
              location={job.location}
              type={job.type}
            />
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            لم تجد الوظيفة المناسبة؟
          </h2>
          <p className="text-gray-600 text-lg mb-8 max-w-2xl mx-auto">
            نحن دائماً نبحث عن مواهب جديدة. أرسل سيرتك الذاتية وسنتواصل معك عند توفر فرصة
            مناسبة لمهاراتك.
          </p>
          <a
            href="mailto:careers@company.com"
            className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition-colors"
          >
            أرسل سيرتك الذاتية
          </a>
        </div>
      </section>
    </div>
  );
}
