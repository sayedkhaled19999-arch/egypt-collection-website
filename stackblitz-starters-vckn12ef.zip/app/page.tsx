import Link from 'next/link';

export default function Home() {
  return (
    <div>
      {/* قسم Hero الرئيسي */}
      <section className="relative bg-gradient-to-l from-blue-700 to-blue-900 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="container mx-auto px-4 py-24 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              مرحباً بك في شركتنا
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-100 leading-relaxed">
              نحن نبني المستقبل معاً من خلال الابتكار والتميز في تقديم الحلول
            </p>
            <Link
              href="/jobs"
              className="inline-block bg-white text-blue-900 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-colors shadow-lg"
            >
              استكشف الوظائف المتاحة
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* قسم نبذة عن الشركة */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* النص */}
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                نبذة عن الشركة
              </h2>
              <p className="text-gray-700 text-lg leading-relaxed mb-6">
                تأسست شركتنا على مبادئ التميز والابتكار والالتزام بتقديم أفضل
                الخدمات لعملائنا. نحن نؤمن بأن النجاح يأتي من خلال العمل الجماعي
                والتفاني في تحقيق الأهداف.
              </p>
              <p className="text-gray-700 text-lg leading-relaxed mb-6">
                لدينا فريق متميز من المحترفين الذين يعملون بشغف لتحقيق رؤيتنا في
                أن نكون الشركة الرائدة في مجالنا. نحن نستثمر في موظفينا ونوفر
                لهم بيئة عمل محفزة وفرص تطوير مستمرة.
              </p>
              <div className="flex gap-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-600 mb-2">
                    10+
                  </div>
                  <div className="text-gray-600">سنوات من الخبرة</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-600 mb-2">
                    500+
                  </div>
                  <div className="text-gray-600">موظف متميز</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-600 mb-2">
                    1000+
                  </div>
                  <div className="text-gray-600">عميل راضٍ</div>
                </div>
              </div>
            </div>

            {/* صورة رئيس الشركة */}
            <div className="order-first md:order-last">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-gray-200 aspect-square">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-32 h-32 bg-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <svg
                        className="w-16 h-16 text-white"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                      </svg>
                    </div>
                    <p className="text-gray-600 font-medium">
                      صورة رئيس الشركة
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-6 text-center">
                <h3 className="text-xl font-bold text-gray-900">أحمد محمد</h3>
                <p className="text-gray-600">الرئيس التنفيذي</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* قسم دعوة للعمل */}
      <section className="py-20 bg-gradient-to-l from-blue-50 to-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            هل أنت مستعد للانضمام إلينا؟
          </h2>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">
            نحن دائماً نبحث عن مواهب جديدة لتنضم إلى فريقنا المتميز. اطلع على
            الفرص الوظيفية المتاحة وابدأ رحلتك المهنية معنا اليوم.
          </p>
          <Link
            href="/jobs"
            className="inline-block bg-blue-600 text-white px-10 py-4 rounded-lg font-bold text-lg hover:bg-blue-700 transition-colors shadow-lg"
          >
            قدّم على وظيفة
          </Link>
        </div>
      </section>

      {/* قسم القيم */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
            قيمنا الأساسية
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-blue-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">الابتكار</h3>
              <p className="text-gray-600 leading-relaxed">
                نسعى دائماً لتقديم حلول مبتكرة ومتطورة تلبي احتياجات عملائنا
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-blue-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                العمل الجماعي
              </h3>
              <p className="text-gray-600 leading-relaxed">
                نؤمن بقوة التعاون والعمل كفريق واحد لتحقيق النجاح
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-blue-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">التميز</h3>
              <p className="text-gray-600 leading-relaxed">
                نلتزم بأعلى معايير الجودة في كل ما نقوم به
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
