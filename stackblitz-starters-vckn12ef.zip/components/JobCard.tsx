import Link from 'next/link';

interface JobCardProps {
  id: string;
  title: string;
  description: string;
  location: string;
  type: string;
}

export default function JobCard({ id, title, description, location, type }: JobCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow border border-gray-100">
      {/* نوع الوظيفة */}
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-bold text-gray-900">{title}</h3>
        <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
          {type}
        </span>
      </div>

      {/* وصف الوظيفة */}
      <p className="text-gray-600 mb-4 leading-relaxed line-clamp-3">
        {description}
      </p>

      {/* الموقع */}
      <div className="flex items-center gap-2 text-gray-500 mb-4">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        <span>{location}</span>
      </div>

      {/* زر التقديم */}
      <Link
        href={`/apply?job=${encodeURIComponent(id)}`}
        className="block w-full bg-blue-600 text-white text-center py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
      >
        قدّم الآن
      </Link>
    </div>
  );
}
